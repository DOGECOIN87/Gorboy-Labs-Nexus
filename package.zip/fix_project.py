#!/usr/bin/env python3
"""
Fix the Gorboy Labs Nexus project - systematic improvements
"""
import os
import shutil

def setup_clean_project():
    # Create clean project structure
    source_dir = "/workspace/Gorboy-Labs-Nexus/Gorboy-Labs-Nexus-main"
    target_dir = "/workspace/gorboy-labs-nexus-fixed"
    
    # Remove target if exists
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir)
    
    # Copy essential files to new structure
    os.makedirs(target_dir)
    
    # Essential files and directories to copy
    items_to_copy = [
        "src",
        "package.json", 
        "vite.config.js",
        "tailwind.config.js",
        "postcss.config.js",
        "index.html",
        ".gitignore"
    ]
    
    for item in items_to_copy:
        src_path = os.path.join(source_dir, item)
        dst_path = os.path.join(target_dir, item)
        if os.path.exists(src_path):
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dst_path)
            else:
                shutil.copy2(src_path, dst_path)
    
    # Create public directory
    os.makedirs(os.path.join(target_dir, "public"), exist_ok=True)
    
    print(f"Clean project structure created at: {target_dir}")
    return target_dir

if __name__ == "__main__":
    setup_clean_project()