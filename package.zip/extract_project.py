#!/usr/bin/env python3
"""
Script to extract the Gorboy-Labs-Nexus project from zip file
"""
import zipfile
import os
import shutil

def extract_project():
    zip_path = "/workspace/user_input_files/Gorboy-Labs-Nexus-main.zip"
    extract_path = "/workspace/Gorboy-Labs-Nexus"
    
    # Remove existing directory if it exists
    if os.path.exists(extract_path):
        shutil.rmtree(extract_path)
    
    # Extract the zip file
    print("Extracting project from zip file...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_path)
    
    print("Extraction completed successfully!")
    
    # List the contents
    print("\nProject structure:")
    for root, dirs, files in os.walk(extract_path):
        level = root.replace(extract_path, '').count(os.sep)
        indent = ' ' * 2 * level
        print(f"{indent}{os.path.basename(root)}/")
        subindent = ' ' * 2 * (level + 1)
        for file in files:
            print(f"{subindent}{file}")

if __name__ == "__main__":
    extract_project()