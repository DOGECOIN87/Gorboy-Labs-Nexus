import { APP_LOGO, APP_TITLE, APP_TAGLINE, APP_DESCRIPTION } from "@/const";
import { WidgetCard } from "@/components/WidgetCard";
import { BackgroundEffects } from "@/components/BackgroundEffects";
// import { Logo3D } from "@/components/Logo3D"; 
import { widgets } from "@/data/widgets";
import { useScrollReveal } from "@/hooks/useScrollReveal";

export default function Home() {
  const widgetsReveal = useScrollReveal();
  const integrationReveal = useScrollReveal();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div 
      className="min-h-screen text-foreground relative overflow-x-hidden"
      style={{
        background: "radial-gradient(circle at 20% 0, #111 0, #000 35%, #000 100%)",
      }}
    >
      <BackgroundEffects />

      {/* Main content */}
      <div className="relative z-[5] container py-8 md:py-12">
        {/* Hero Section */}
        <header 
          className="border border-border rounded-lg p-6 md:p-8 mb-6 md:mb-8 relative glass-panel text-center md:text-left neon-glow"
        >
          {/* Corner accent using CSS class */}
          <div className="corner-accent" />

          <div className="mb-4 md:mb-6">
            <img
              src={APP_LOGO}
              alt={APP_TITLE}
              className="max-w-[200px] md:max-w-[220px] mx-auto md:mx-0 transition-all duration-300 hover:scale-105"
            />
          </div>

          <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold tracking-wider uppercase mb-3">
            {APP_TITLE}
          </h1>

          <div className="text-sm md:text-base tracking-widest uppercase text-accent mb-4 md:mb-6">
            {APP_TAGLINE}
          </div>

          <p className="text-sm md:text-base leading-relaxed uppercase text-muted-foreground mb-6">
            {APP_DESCRIPTION}
          </p>

          <div className="flex gap-4 justify-center md:justify-start">
            <button
              onClick={() => scrollToSection("widgets")}
              className="btn-primary hover:-translate-y-1"
            >
              Widgets
            </button>
            <button
              onClick={() => scrollToSection("integration")}
              className="btn-secondary hover:-translate-y-1"
            >
              Integration
            </button>
          </div>
        </header>

        {/* 3D Logo Section - Optional Enhancement */}
        {/* <section className="mb-8">
          <Logo3D />
        </section> */}

        {/* What is Gorboy Labs */}
        <section className="border border-border rounded-lg p-6 md:p-8 mb-6 bg-background/95 card-hover">
          <h2 className="text-sm md:text-base tracking-wider uppercase text-muted-foreground mb-4">
            <span className="text-accent font-semibold">00</span> · what is gorboy labs
          </h2>
          <p className="text-sm md:text-base leading-relaxed mb-4">
            Gorboy Labs is the experimental wing of the Gorboy ecosystem — tools, generators,
            mini-widgets and add-ons for meme founders.
          </p>
          <p className="text-sm md:text-base leading-relaxed">
            Pure HTML / CSS / JS. Zero VC. Zero budget. Built for people who
            want to ship fast on <strong className="text-accent">Gorbagana</strong>.
          </p>
        </section>

        {/* Widget Stack */}
        <section 
          id="widgets" 
          ref={widgetsReveal.ref}
          className={`border border-border rounded-lg p-6 md:p-8 mb-6 bg-background/95 transition-all duration-700 ${
            widgetsReveal.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <h2 className="text-sm md:text-base tracking-wider uppercase text-muted-foreground mb-6">
            <span className="text-accent font-semibold">01</span> · widget stack
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {widgets.map((widget, index) => (
              <div
                key={widget.id}
                className="transition-all duration-500"
                style={{
                  transitionDelay: `${index * 100}ms`,
                  opacity: widgetsReveal.isVisible ? 1 : 0,
                  transform: widgetsReveal.isVisible ? 'translateY(0)' : 'translateY(20px)',
                }}
              >
                <WidgetCard widget={widget} />
              </div>
            ))}
          </div>
        </section>

        {/* Integration Guide */}
        <section 
          id="integration" 
          ref={integrationReveal.ref}
          className={`border border-border rounded-lg p-6 md:p-8 mb-6 bg-background/95 transition-all duration-700 ${
            integrationReveal.isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <h2 className="text-sm md:text-base tracking-wider uppercase text-muted-foreground mb-4">
            <span className="text-accent font-semibold">02</span> · integration guide
          </h2>
          
          <p className="text-sm md:text-base leading-relaxed mb-4">
            All Gorboy Labs widgets are designed to be
            <strong className="text-accent"> copy-paste only</strong>. No backend. No SDK.
          </p>

          <ol className="space-y-3 mb-4 text-sm md:text-base leading-relaxed list-decimal list-inside">
            <li className="transition-colors hover:text-accent cursor-default">Pick a widget above.</li>
            <li className="transition-colors hover:text-accent cursor-default">Use the COPY button to grab its embed snippet.</li>
            <li className="transition-colors hover:text-accent cursor-default">Paste into your website / landing / tools page.</li>
          </ol>

          <p className="text-sm md:text-base leading-relaxed text-muted-foreground">
            If you can edit a webpage — you can embed Gorboy Labs.
          </p>
        </section>

        {/* Footer */}
        <footer className="text-center text-sm tracking-wider uppercase text-muted-foreground space-y-2 py-8">
          <div className="transition-colors hover:text-accent cursor-default">GORBOY LABS — MEME.BUILD.REPEAT.</div>
          <div className="text-xs text-muted-foreground">exclusive for gorbagana chain</div>
        </footer>
      </div>
    </div>
  );
}
