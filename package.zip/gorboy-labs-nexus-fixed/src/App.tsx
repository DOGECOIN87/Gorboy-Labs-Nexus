import { Toaster } from "sonner";
import Home from "@/pages/Home";

function App() {
  return (
    <>
      <Toaster position="top-right" theme="dark" />
      <div className="min-h-screen bg-background text-foreground font-sans">
        <Home />
      </div>
    </>
  );
}

export default App;
