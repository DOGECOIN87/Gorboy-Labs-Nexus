import { toast } from "sonner";

export interface WidgetData {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  status: "live" | "coming-soon";
  slot?: string;
  embedCode?: string;
  demoUrl?: string;
  howToEmbed?: string[];
}

interface WidgetCardProps {
  widget: WidgetData;
}

export function WidgetCard({ widget }: WidgetCardProps) {
  const handleCopyEmbed = () => {
    if (widget.embedCode) {
      navigator.clipboard.writeText(widget.embedCode);
      toast.success("Copied to clipboard!");
    }
  };

  const isComingSoon = widget.status === "coming-soon";

  return (
    <article 
      className={`border border-border rounded-lg p-4 md:p-6 bg-background/95 relative overflow-hidden transition-all duration-200 card-hover ${
        isComingSoon ? "opacity-60" : ""
      }`}
    >
      {/* Hover gradient effect */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-0 hover:opacity-100 transition-opacity duration-200 bg-gradient-to-br from-accent/5 to-transparent"
      />

      {/* Status label */}
      <div 
        className={`absolute top-3 right-3 text-xs px-3 py-1.5 border uppercase tracking-wide font-medium bg-background/90 rounded-md ${
          widget.status === "live" 
            ? "border-accent text-accent" 
            : "border-border border-dashed text-muted-foreground"
        }`}
      >
        {widget.status === "live" ? "live" : widget.slot?.toLowerCase() || "coming soon"}
      </div>

      {/* Title */}
      <h3 className="text-base md:text-lg font-semibold uppercase tracking-wider mb-2 pr-16">
        {widget.title}
      </h3>

      {/* Subtitle */}
      {widget.subtitle && (
        <div className="text-sm uppercase tracking-wide text-muted-foreground mb-3">
          {widget.subtitle}
        </div>
      )}

      {/* Description */}
      <p className="text-sm md:text-base text-muted-foreground mb-4 leading-relaxed">
        {widget.description}
      </p>

      {!isComingSoon && (
        <>
          {/* How to embed */}
          {widget.howToEmbed && (
            <div className="mb-4">
              <h4 className="text-sm uppercase tracking-wide text-accent font-medium mb-2">
                How to embed
              </h4>
              <ol className="space-y-1.5 text-sm text-muted-foreground list-decimal list-inside">
                {widget.howToEmbed.map((step, index) => (
                  <li key={index} className="hover:text-foreground transition-colors cursor-default">{step}</li>
                ))}
              </ol>
            </div>
          )}

          {/* Embed code */}
          {widget.embedCode && (
            <div className="relative mb-4">
              <button
                onClick={handleCopyEmbed}
                className="absolute top-2 right-2 px-3 py-1.5 text-xs tracking-wide uppercase bg-accent text-accent-foreground rounded-md transition-all duration-150 hover:bg-accent/90 hover:scale-105 z-10 min-w-[60px] font-medium"
              >
                Copy
              </button>
              <pre className="p-3 md:p-4 bg-card border border-border rounded-lg whitespace-pre overflow-x-auto text-xs font-mono">
                {widget.embedCode}
              </pre>
            </div>
          )}

          {/* Demo button */}
          {widget.demoUrl && (
            <a
              href={widget.demoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center mt-2 px-4 py-2 text-sm uppercase tracking-wide border border-foreground bg-background text-foreground transition-all duration-150 hover:bg-foreground hover:text-background hover:shadow-lg hover:-translate-y-0.5 rounded-md font-medium"
            >
              Open {widget.title} demo
              <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </a>
          )}
        </>
      )}
    </article>
  );
}
