import { APP_LOGO } from "@/const";

export function BackgroundEffects() {
  return (
    <>
      {/* Grid overlay */}
      <div
        className="fixed inset-0 pointer-events-none z-0 opacity-[0.12] transition-opacity duration-1000"
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,0.06) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.06) 1px, transparent 1px)
          `,
          backgroundSize: "40px 40px",
        }}
      />

      {/* Enhanced scanlines */}
      <div
        className="fixed inset-0 pointer-events-none z-[1] opacity-30 mix-blend-soft-light"
        style={{
          backgroundImage: "linear-gradient(rgba(217,255,245,0.08) 1px, transparent 1px)",
          backgroundSize: "100% 2px",
        }}
      />

      {/* Accent glow effects */}
      <div 
        className="fixed top-0 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl pointer-events-none z-0 animate-pulse-subtle"
      />
      <div 
        className="fixed bottom-0 right-1/4 w-80 h-80 bg-accent/5 rounded-full blur-3xl pointer-events-none z-0 animate-pulse-subtle"
        style={{ animationDelay: '1s' }}
      />

      {/* Watermark logo */}
      <div className="fixed top-4 right-4 z-[2] opacity-15 pointer-events-none transition-opacity duration-1000 hover:opacity-25">
        <img
          src={APP_LOGO}
          alt="Gorboy Labs Watermark"
          className="w-16 h-16 md:w-20 md:h-20 filter drop-shadow-lg"
        />
      </div>
    </>
  );
}
